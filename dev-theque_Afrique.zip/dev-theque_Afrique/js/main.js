// Vérification de l'authentification
document.addEventListener('DOMContentLoaded', function() {
    // Vérifier si l'utilisateur est déjà connecté
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    
    // Mettre à jour l'interface utilisateur en fonction de l'état d'authentification
    updateUIBasedOnAuth(isAuthenticated);
    
    // Gestion des liens nécessitant une authentification
    const authRequiredLinks = document.querySelectorAll('.auth-required');
    authRequiredLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Si l'utilisateur est déjà connecté, rediriger vers la destination
            if (isAuthenticated) {
                const targetUrl = this.getAttribute('data-target');
                window.location.href = targetUrl;
            } else {
                // Sinon, ouvrir la modale de connexion
                openModal(document.getElementById('login-modal'));
            }
        });
    });

    // Gestion des modales d'authentification
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const joinCommunityBtn = document.getElementById('join-community-btn');
    const loginModal = document.getElementById('login-modal');
    const registerModal = document.getElementById('register-modal');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const switchToRegister = document.getElementById('switch-to-register');
    const switchToLogin = document.getElementById('switch-to-login');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    // Fonction pour ouvrir une modale
    function openModal(modal) {
        // Fermer toutes les modales d'abord
        closeAllModals();
        
        // Ouvrir la modale spécifiée
        modal.classList.add('show');
        document.body.style.overflow = 'hidden'; // Empêcher le défilement
    }

    // Fonction pour fermer toutes les modales
    function closeAllModals() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
        document.body.style.overflow = ''; // Rétablir le défilement
    }

    // Ouvrir la modale de connexion
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            openModal(loginModal);
        });
    }

    // Ouvrir la modale d'inscription
    if (registerBtn) {
        registerBtn.addEventListener('click', function() {
            openModal(registerModal);
        });
    }

    // Ouvrir la modale d'inscription depuis le bouton "Rejoindre la communauté"
    if (joinCommunityBtn) {
        joinCommunityBtn.addEventListener('click', function() {
            openModal(registerModal);
        });
    }

    // Fermer les modales avec le bouton X
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', closeAllModals);
    });

    // Fermer les modales en cliquant en dehors
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeAllModals();
        }
    });

    // Basculer entre connexion et inscription
    if (switchToRegister) {
        switchToRegister.addEventListener('click', function(e) {
            e.preventDefault();
            openModal(registerModal);
        });
    }

    if (switchToLogin) {
        switchToLogin.addEventListener('click', function(e) {
            e.preventDefault();
            openModal(loginModal);
        });
    }

    // Gérer la soumission du formulaire de connexion
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            const rememberMe = document.getElementById('remember-me').checked;
            
            // Simuler une connexion réussie (à remplacer par une vraie authentification)
            localStorage.setItem('isAuthenticated', 'true');
            localStorage.setItem('userEmail', email);
            localStorage.setItem('userName', email.split('@')[0]); // Pour l'exemple
            if (rememberMe) {
                localStorage.setItem('rememberMe', 'true');
            }
            
            alert('Connexion réussie! Bienvenue sur Dev-thèque_Afrique.');
            closeAllModals();
            
            // Mettre à jour l'interface utilisateur
            updateUIBasedOnAuth(true);
            
            // Rediriger vers la page principale si nécessaire
            const lastAttemptedUrl = localStorage.getItem('lastAttemptedUrl');
            if (lastAttemptedUrl) {
                localStorage.removeItem('lastAttemptedUrl');
                window.location.href = lastAttemptedUrl;
            }
        });
    }

    // Gérer la soumission du formulaire d'inscription
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('register-name').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm-password').value;
            const termsAccepted = document.getElementById('terms').checked;
            
            // Vérification simple des mots de passe
            if (password !== confirmPassword) {
                alert('Les mots de passe ne correspondent pas.');
                return;
            }
            
            // Simuler une inscription réussie (à remplacer par une vraie création de compte)
            localStorage.setItem('isAuthenticated', 'true');
            localStorage.setItem('userEmail', email);
            localStorage.setItem('userName', name);
            localStorage.setItem('rememberMe', 'true');
            
            alert('Inscription réussie! Bienvenue dans la communauté Dev-thèque_Afrique.');
            closeAllModals();
            
            // Mettre à jour l'interface utilisateur
            updateUIBasedOnAuth(true);
            
            // Rediriger vers la page principale si nécessaire
            const lastAttemptedUrl = localStorage.getItem('lastAttemptedUrl');
            if (lastAttemptedUrl) {
                localStorage.removeItem('lastAttemptedUrl');
                window.location.href = lastAttemptedUrl;
            }
        });
    }
});

// Fonction pour mettre à jour l'interface utilisateur en fonction de l'état d'authentification
function updateUIBasedOnAuth(isAuthenticated) {
    const authButtons = document.querySelector('.auth-buttons');
    const userMenu = document.createElement('div');
    userMenu.className = 'user-menu';
    
    if (isAuthenticated) {
        // Si l'utilisateur est connecté, remplacer les boutons de connexion/inscription
        // par un menu utilisateur avec bouton de déconnexion
        if (authButtons) {
            const userName = localStorage.getItem('userName') || 'Utilisateur';
            
            userMenu.innerHTML = `
                <span class="user-name">${userName}</span>
                <button id="logout-btn" class="btn-auth logout">Déconnexion</button>
            `;
            
            authButtons.parentNode.replaceChild(userMenu, authButtons);
            
            // Ajouter l'événement de déconnexion
            const logoutBtn = document.getElementById('logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', function() {
                    localStorage.removeItem('isAuthenticated');
                    localStorage.removeItem('userEmail');
                    localStorage.removeItem('userName');
                    localStorage.removeItem('rememberMe');
                    
                    // Rafraîchir la page pour mettre à jour l'interface utilisateur
                    window.location.reload();
                });
            }
        }
    }
}

// Animation du menu au défilement
window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// Navigation active selon la section visible
document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('nav ul li a');

    function highlightNavigation() {
        const scrollPosition = window.scrollY + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + sectionId) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', highlightNavigation);
    highlightNavigation(); // Exécuter une fois au chargement
});

// Animation fluide pour les liens d'ancrage
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        
        // Ignorer les liens avec auth-required qui ont été traités séparément
        if (this.classList.contains('auth-required')) {
            return;
        }
        
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// Formulaire de newsletter
const newsletterForm = document.querySelector('.newsletter-form');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const emailInput = this.querySelector('input[type="email"]');
        const email = emailInput.value.trim();
        
        if (email) {
            // Simulation d'envoi de formulaire (à remplacer par une vraie soumission)
            alert('Merci pour votre inscription! Vous recevrez bientôt nos actualités.');
            emailInput.value = '';
        }
    });
}

// Animation des cartes au défilement
function animateOnScroll() {
    const elements = document.querySelectorAll('.feature-card, .resource-card, .testimonial');
    
    elements.forEach(element => {
        const elementPosition = element.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.3;
        
        if (elementPosition < screenPosition) {
            element.classList.add('animated');
        }
    });
}

window.addEventListener('scroll', animateOnScroll);
document.addEventListener('DOMContentLoaded', animateOnScroll);

// Ajouter cette fonction pour protéger toutes les pages sauf index.html
function checkProtectedPage() {
    // Si ce n'est pas la page d'index et que l'utilisateur n'est pas connecté
    if (window.location.pathname !== '/index.html' && 
        window.location.pathname !== '/' && 
        localStorage.getItem('isAuthenticated') !== 'true') {
        
        // Redirection vers la page d'accueil avec paramètre d'accès refusé
        window.location.href = 'index.html?access=denied';
    }
}

// Exécuter cette vérification au chargement de chaque page
document.addEventListener('DOMContentLoaded', checkProtectedPage); 